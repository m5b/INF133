const PORT = 80;
var http = require('http');

var server = http.createServer(function(req,res){
    console.log(req.method + " " + req.url);
    res.writeHead(200);
    res.end(req.method + " " + req.url);
});


server.listen(PORT, 'localhost', function() {
  console.log('Server is running on port ' + PORT);
})