const PORT = 80;
var http = require('http');
var path = require('path');
var fs = require('fs');

// create a lookup object for common content types
const contentTypes = {
    html: 'text/html',
    json: 'text/json',
    js: 'text/javascript'
}

var server = http.createServer(function(req,res){
    console.log(req.method + " " + req.url);

    //build the path to requested file on server
    var filePath = path.join('.', req.url);

    //quick hack to demonstrate routing concept - not robust!
    if (req.url == "/"){
        filePath = "index.html"
    }else if (req.url == "/people"){
        filePath = "data.json"
    }

    console.log(filePath);

    //read and process file
    fs.readFile(filePath, function(err, content){
        if (err){
            res.statusCode = 404;
            return res.end("Resource not found");
        }

        var contentType = 'text/html'; //set html as default
        
        // assume a file
        var ext = path.extname(filePath);
        contentType = contentTypes[ext.slice(1)]; //isolate extension

        //set content type and send a response
        res.setHeader('Content-Type', contentType);
        res.end(content);
    });
});

//start the server
server.listen(PORT, 'localhost', function() {
  console.log('Server is running on port ' + PORT);
})