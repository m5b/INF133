"use strict";
/* Typescript Type Declarations */
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
/*

Generate using --declaration option:
> tsc --declaration myfile.ts

Install types for existing libraries using npm

npm install --save @types/your-lib-name

> npm install --save @types/jquery

*/
function area(shape, width, height) {
    var area = width * height;
    return shape + " of area " + area + " cm^2.";
}
function area2(shape) {
    var area = shape.width * shape.height;
    return shape.name + " of area " + area + " cm^2.";
}
/* Inheritance*/
/*


*/
var Shape3D = /** @class */ (function () {
    function Shape3D() {
    }
    return Shape3D;
}());
var Shape4D = /** @class */ (function (_super) {
    __extends(Shape4D, _super);
    function Shape4D() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return Shape4D;
}(Shape3D));
/* Generics */
/*

*/
function identity(arg) {
    return arg;
}
var id = identity("Hello!");
$(function () {
    //type decs
    //$("p").text(area('square', 15, 15));
    //interfaces
    var rect = { name: "square", width: 15, height: 15 };
    console.log(area2(rect));
});
