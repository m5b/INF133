declare function area(shape: string, width: number, height: number): string;
