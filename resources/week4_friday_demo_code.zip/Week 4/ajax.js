
/*

URI provided by:
https://www.weather.gov/documentation/services-web-api

*/
const URI = "https://api.weather.gov/gridpoints/SGX/38,58/forecast"
const URI2 = "/weather.json"

$(() => {
    $("#weather").click(function(){
        fetch(URI).then(function(response){
            return response.json();
        }, error).then(function(data){
            console.log(data.properties.periods);
            data.properties.periods.forEach(p => {
                $("#response").append(p.name + ": " + p.shortForecast + "<br />");
            });
        }).catch(function(err){
            console.log(err.message);
        });

        $("#response").append("Response Sent <br />");
    });

    function success(res){
        $("#response").append("OK " + res);
    }

    function error(res){
        $("#response").append("ERROR " + res);
        console.log(res);
    }

});