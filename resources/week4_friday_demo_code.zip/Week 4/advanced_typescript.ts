/* Typescript Type Declarations */

import { extend } from "jquery";

/*

Generate using --declaration option:
> tsc --declaration myfile.ts

Install types for existing libraries using npm

npm install --save @types/your-lib-name

> npm install --save @types/jquery



*/

function area(shape:string, width:number, height:number):string{
    var area:number = width * height;
    return shape + " of area " + area + " cm^2.";
}

/* Interfaces */

interface Shape{
    name: string;
    width: number;
    height: number;
    color?: string; // ? = optional
}



/* Inheritance*/
/*
 In the recording, I mistakenly declared Shape3D a class...thus the 
 errors related to use of extends
*/

interface Shape3D extends Shape{
    volume: number;
    area(shape:Shape):string;
}

class FlexiShape implements Shape3D{
    volume: number;
    name: string;
    width: number;
    height: number;
    color?: string | undefined;

    constructor(shape: Shape){
        this.name = shape.name;
        this.width = shape.width;
        this.height = shape.height;
    }

    area():string{
        var area:number = this.width * this.height;
        return this.name + " has area " + area + " cm^2.";
    }
}


/* Generics */
/*

*/

function identity<T>(arg: T) : T{
    return arg;
}

let id = identity<string>("Hello!");


$(() => {
    //type decs
    //$("p").text(area('square', 15, 15));

    //interfaces
    console.log(area("square", 15, 15));

    //inheritance
    var rect = {name: "square", width: 15, height: 15};
    var fs = new FlexiShape(rect);
    console.log(fs.area())

});