var uri = "http://localhost:8001/people";

document.getElementById("loadbtn").addEventListener('click', (ev)=>{
    // console.log("Missing call to fetchData function!");
    fetchData(uri);
});

async function fetchData(uri){
    try{
        const response = await fetch(uri);
        const data = await response.json();
        renderData(data);
    }catch(err){
        console.log(err);
    }
}

function _fetchData(uri){
    var promise = fetch(uri);
    promise.then(function(res){
        return res.json();
    }).then(function(data){
        renderData(data);
    });
}

function renderData(people){
    var xage = 20;
    // 1. Filter: Filter people under the age of 30
    const underXAge = people.filter(function (person) {
        return person.age < xage;
    });

    // 2. Map: Create an array of names
    const names = people.map(function (person) {
        return {p: person.name, c: person.city};
    });

    // 3. Reduce: Calculate the average age
    const totalAge = people.reduce(function (sum, person) {
        return sum + person.age;
    }, 0);

    const averageAge = totalAge;// / people.length;

    // 4. Reduce (object accumulator): Calculate statistics about people
    const statistics = people.reduce(function (accumulator, person) {
        // use OR operator to default totalAge count
        // http://blog.niftysnippets.org/2008/02/javascripts-curiously-powerful-or.html

        accumulator.totalAge = (accumulator.totalAge || 0) + person.age;
        accumulator.numPeople = (accumulator.numPeople || 0) + 1;
        return accumulator;
    }, {});

    // Calculate the average age
    // dynamically expand statistics object to include property 'averageAge'
    statistics.averageAge = statistics.totalAge / statistics.numPeople;

    const resultsLeft = document.getElementById("left");
    resultsLeft.innerHTML = `
        <li class="list-group-item">People under ${xage}: <pre>${displayData(underXAge)}</pre></li>
    `;
    resultsRight = document.getElementById("right");
    resultsRight.innerHTML = `
        <li class="list-group-item">Names of people: <pre>${displayData(names)}</pre></li>
        <li class="list-group-item">Average age of people: ${averageAge}</li>
    `;
}

// Formatting and DOM render
function displayData(data) {
    const formattedData = JSON.stringify(data, null, 2);
    return formattedData.slice(1, formattedData.length - 1); // Remove outer curly braces
}