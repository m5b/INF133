import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { PeopleComponent } from './people/people.component';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, CommonModule, PeopleComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  title = 'inf133-demo';
  loadMessage = "";
  alertClass = "alert ";// alert-primary";

  peopleDataLoaded(result: boolean){
    if(result){
      this.loadMessage = "Success";
      this.alertClass += " alert-primary";
    }else{
      this.loadMessage = "Error. Is the Node Server running?";
      this.alertClass += " alert-danger";
    }
  }
}
