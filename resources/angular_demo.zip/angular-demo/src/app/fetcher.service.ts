import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FetcherService {
  serverURI:string = "http://localhost:8001";

  constructor() { }

  async getPeopleData(): Promise<[]>{
    try{
      var promise = await fetch(this.serverURI + "/people");
      return await promise.json();
    }catch{
      throw("fetch request failed");
    }
  }
}
