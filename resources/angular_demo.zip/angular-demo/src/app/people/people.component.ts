import { Component, Input, Output, EventEmitter } from '@angular/core';
import { FetcherService } from '../fetcher.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-people',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './people.component.html',
  styleUrl: './people.component.scss'
})
export class PeopleComponent {
  @Input() title:string = "People Component";
  @Output() dataLoaded = new EventEmitter<boolean>();
  data:[]=[];

  /*
  NOTE: I did not cover this in class on 2/5, but will discuss more the 2/12.
  
  Rather than add the fetch logic to a single component, it is better to abstract into 
  it's own class/service.
  
  ng generate service fetcher

  Now, when fetch is needed, just inject into desired component as a constructor param
  */
  constructor(private fetcher: FetcherService){}

  async loadData(){
    var result:boolean = false;
    try{
      this.data = await this.fetcher.getPeopleData();
      result = true;
    }catch{
      console.log("loadData fetch error");
    }
    this.dataLoaded.emit(result);
  }
}
