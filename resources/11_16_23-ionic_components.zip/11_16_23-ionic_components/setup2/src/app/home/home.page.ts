import { Component } from '@angular/core';
import { AlertController, ModalController } from '@ionic/angular';
import { ModalPage } from '../modal/modal.page';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  shoppingList:any[] = [
    {'item':'Broccoli', 'inCart':false},
    {'item':'Bread', 'inCart':false},
    {'item':'Orange Juice', 'inCart':true},
    {'item':'Apples', 'inCart':false}
  ];

  constructor(private alertController:AlertController, private modalController:ModalController) {}

  async addItem() {
    //TODO: use the alert controller to create and display a text input field, and add that to the shopping list.
    const alert = await this.alertController.create({
      header: 'What would you like to add?',
      inputs: [
        {
          name: 'item',
          type: 'text',
          placeholder: 'Add an item'
        }
      ],
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (data) => {
            //No need to do anything
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Ok',
          handler: (data) => {
            console.log(data);
            this.shoppingList.push({'item':data.item, 'inCart':false});
          }
        }
      ]
    });

    await alert.present();
  }

  async deleteItems() {
   //TODO: use the alert controller to create and display a set of checkboxes for each item in the shopping list.
   //For each item checked, delete the item from the list.
       var inputs:any[] = this.shoppingList.map((item:any) => {
      return {name:'toRemove', type:'checkbox', label:item.item, value:item.item};
    });

    const alert = await this.alertController.create({
      header: 'Which would you like to delete?',
      inputs: inputs,
      buttons: [
        {
          text: 'Cancel',
          role: 'cancel',
          cssClass: 'secondary',
          handler: (data) => {
            //No need to do anything
            console.log('Confirm Cancel');
          }
        }, {
          text: 'Ok',
          handler: (data) => {
            console.log(data);
            this.shoppingList = this.shoppingList.filter((item) => {
              return !data.includes(item.item);
            });
          }
        }
      ]
    });

    await alert.present();
  }

  async checkOut() {
    var boughtItems = this.shoppingList.filter((item:any) => {
      return item.inCart;
    });
    var unboughtItems = this.shoppingList.filter((item:any) => {
      return !item.inCart;
    });
    this.shoppingList = unboughtItems;
    var itemsPurchased = boughtItems.map((item:any) => {
      return item.item;
    });
    const modal = await this.modalController.create({
    component: ModalPage,
    componentProps: {
        'itemsPurchased': itemsPurchased,
      }
    });
    await modal.present();
  }

}
