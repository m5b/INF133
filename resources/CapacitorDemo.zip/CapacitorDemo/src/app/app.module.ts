import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouteReuseStrategy } from '@angular/router';

//TODO: Import IonicStorageModule
import { Storage, IonicStorageModule } from '@ionic/storage-angular';
import { Drivers } from '@ionic/storage';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { StorageService } from './storage-service.service';

//TODO: Add IonicStorageModule to NgModule
@NgModule({
  declarations: [AppComponent],
  // imports: [BrowserModule, IonicModule.forRoot(), AppRoutingModule, IonicStorageModule.forRoot({
  //   name: '__mydb',
  //   driverOrder: [Drivers.IndexedDB, Drivers.LocalStorage]
  // })],
  imports: [BrowserModule, IonicModule.forRoot(), AppRoutingModule, 
    IonicStorageModule.forRoot()
  ],
  providers: [{ provide: RouteReuseStrategy, useClass: IonicRouteStrategy }, StorageService, Storage],
  bootstrap: [AppComponent],
})
export class AppModule {}
