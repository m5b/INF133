import { Component } from '@angular/core';
//TODO preferences
import { Preferences } from '@capacitor/preferences';
//TODO storage
import { StorageService } from '../storage-service.service';
import { Platform } from '@ionic/angular';

//TODO camera
import { CameraResultType, Camera } from '@capacitor/camera';
//TODO Local Notification
import { LocalNotifications } from '@capacitor/local-notifications';
//TODO Sharing
import { Share } from '@capacitor/share';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage { 
  name:string = "Unknown";
  imageSrc:string = "";
  //TODO: Inject Storage
  constructor(private storageService: StorageService, private platform: Platform) {
    // this.loadName().then((data)=>{
    //   this.name = data.value || "Unknown";
    // })

    storageService.notifyReady.subscribe({
      next: (event: any) => {
        console.log(event)
        this.getName();
      }
    })
  }

  async sharePhoto(){
    await Share.share({
      title: 'Teaching Capacitor',
      text: 'Just chillin at the lectern',
      //url: this.imageSrc, <--slightly more complicated
      url: 'https://inf133.markbaldw.in',
      dialogTitle: 'Share your favorite website',
    });
  }

  async scheduleNotification() {
    await LocalNotifications.requestPermissions();
    await LocalNotifications.schedule({
      notifications: [{
        title: 'Sample Notification',
        body: 'This is a test notification!',
        id: 1,
        schedule: { at: new Date(Date.now() + 1000 * 5) } // Schedule notification after 5 seconds
      }]
    });

    console.log('Notification scheduled!');
  }

  setName(){
    this.storageService.set('name', this.name);
    console.log(this.name)
  }

  getName(){
    this.storageService.get('name').then((data)=>{
      console.log("got name")
      this.name = data;
    });
  }

  //preferences
  async storeName(){
    await Preferences.set({
      key: 'name',
      value: this.name,
    });
  }
  async loadName(){
    return await Preferences.get({
      key: 'name',
    });
  }

  async takePicture(){
    const image = await Camera.getPhoto({
      quality: 80,
      allowEditing: false,
      resultType: CameraResultType.Uri
    });

    var imageUrl = image.webPath;
    this.imageSrc = imageUrl || "";
  }
}
