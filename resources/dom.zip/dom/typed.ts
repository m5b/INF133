var x:string;
/*
Number
Boolean
String
Void 
Null
Undefined
Any
*/
x = 'hello';

console.log(x);

function myfunc(x:number, y:string, z:any):string{
    return "hello";
}

class Shape{
    area: number;
    color: string;
    name: string;

    constructor(name:string){
        this.name = name;
    }

    print(){
        console.log(this.name);
    }
}

var shape = new Shape('circle');
shape.print();