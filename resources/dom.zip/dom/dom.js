
//document.X <-- the DOM

//document.write("<h1>New Heading</h1>");

var title = "DOM Demo";
document.write("<h1>" + title + "</h1>");


function ready(){
    /* selecting elements */
    
    var list = document.getElementById("thelist");
    console.log(list);

    var ele = document.getElementsByClassName("container");
    console.log(ele);

    var ele = document.getElementsByTagName("li");
    console.log(ele);

    //What about only aside list?
    var cssSelector = 'aside li';
    var ele = document.querySelector(cssSelector);
    console.log(ele); //<-- the first only

    var ele = document.querySelectorAll(cssSelector);
    console.log(ele); //<-- all

    ele[0].textContent = "Hello";
    ele[1].textContent = "Goodbye";


    //If you need the HTML too
    var listHtml = list.innerHTML;
    console.log(listHtml);

    //or perhaps the parent?
    console.log(list.parentNode);

    //edit elements too
    ele[0].classList.add("red");
    ele[1].style.color="blue";

    //interactivity
    /*
    */
    var btn = document.getElementById("btn1");
    btn.addEventListener('mouseover', click);

    btn.addEventListener('click', function(event){
        console.log(event.target);
    });

}

function click(){
    console.log("clicked");
}