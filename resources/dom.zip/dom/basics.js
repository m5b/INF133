console.log("Hello There");

/* dynamic typing */
var x = 'hello';
x = 5;

console.log(typeof(x));

/* equality */

var num = 10;
var str = '10';

// === strict, same as == but without type conversion
console.log(num === str);

/* loops and conditionals */

var i = 5;

if (i > 5){
    console.log("i is greater than 5");
}else if( i >= 3){
    console.log("i is between 3 and 5");
}else{
    console.log("i is less than 3");
}

for (var j=0; j< 5; j++){
    //console.log(j);
}

/* built-in methods */

// uses dot notation

var className = "in4matx 133";

console.log(className);
var upperClassName = className.toUpperCase();
console.log(upperClassName);

console.log(className.substring(0,7));
console.log(upperClassName.indexOf('MAT') >= 0);

/* Arrays */

var letters = ['a', 'b', 'c'];
var numbers = [1,2,3];

var things = ['raindrops', 2.5, true, [5,9,8]]; //<-- can nest!

var empty = [];
var blank = new Array(5); //empty array with 5 reseverved indices

// Java like notation for accessing

console.log(letters[1]);
console.log(things[3][1]);

//Arrays will automatically grow if assigned out of bounds

console.log(letters.length);
letters[7] = 'g';
console.log(letters.length);

//Arrays have their own methods

letters.push('h');
console.log(letters);

var alphabet = letters.join('');

console.log(alphabet);

/* JavaScript Objects */

//basically an unordered set of key/value pairs 
//(e.g., HashMap in Java or Dictionary in Python)

ages = {alice:40, bob:35, veronica:22};
console.log(ages.bob);

console.log(ages);

empty = new Object();
empty.name = 'Sammy';
console.log(empty.name);

/* The Window object */

var innerWidth = window.innerWidth;
var innerHeight = window.innerHeight;
var xPos = window.screenX; //offset from screen edge
var yPos = window.screenY; //offset from screen edge

var dim = `${innerWidth} x ${innerHeight} || ${xPos} x ${yPos}`;
console.log(dim);


var url = window.location.href;
console.log(url);


console.log(confirmed);
console.log(response);

/* DO NOT DO THESE THINGS */
/*

//window.alert(dim);
//var confirmed = window.confirm("Are you sure?");
//var response = window.prompt("What is your instruction?");

*/
// Some other stuff...
//window.open("https://inf133.markbaldw.in");
//window.scrollTo(500, 1000);
//window.close();


