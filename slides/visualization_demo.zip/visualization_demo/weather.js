// run the code once the DOM is loaded
document.addEventListener('DOMContentLoaded', function (event) {
	var tempSchema = {
		"$schema": "https://vega.github.io/schema/vega-lite/v5.json",
		"data": { "url": "seattle-weather.json"},
	}

    var precipSchema = {
        "$schema": "https://vega.github.io/schema/vega-lite/v5.json",
        data: {url: "https://vega.github.io/vega-lite/data/seattle-weather.csv"},
        mark: "bar",
        encoding: {
        }
    }
    
	vegaEmbed('#plot1', tempSchema, {actions:false});

    // uncomment to display second plot
	// vegaEmbed('#plot2', precipSchema, {actions:false});
});
